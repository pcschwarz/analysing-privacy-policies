# THIS IS A BACKUP FROM THE DATAPROCESSING NOTEBOOKS AND A BACKUP FROM THE ORIGINAL GITLAB OF MY UNIVERSITY
I just added a already cleaned up 10_medical_and_fitness.json 
because the full one with all 4000 privacy policies might be too large so Heroku wont let me use their free deployment plan anymore^^


# How to run this?

First you should install the same Python environment. In case you use Anaconda you can use my
Environment.yml to install the same environment as I did. 
Here is a guide how to install an Environment from a .yml file https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html

In case you are running windows or the provided yml file does not work for you, check the backup_environments folder.

# How to start the Notebook?

Open Medical_VS_Fitness_Final.ipynb in JuypterLabs/JupyterNotebook (https://jupyter.org/install) and run it.
At the beginning of the Notebook you can declare which .json file you want to process. 
By default its "10_medical_and_fitness.json". 